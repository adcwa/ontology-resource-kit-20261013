OGC(r) OGC API - Connected Systems ReadMe.txt
=============================================

OGC(r) OGC API - Connected Systems - Part 1: Feature Resources
-----------------------------------------------------------------------

OGC API - Connected Systems - Part 1: Feature Resources

More information may be found at
 https://www.ogc.org/standards/ogcapi-connected-systems

The most current schema are available at http://schemas.opengis.net/
and all OGC schemas may be downloaded in a complete bundle from
http://schemas.opengis.net/SCHEMAS_OPENGIS_NET.zip

* Latest version is: http://schemas.opengis.net/ogcapi/common/

-----------------------------------------------------------------------

2025-07-15  Alexandre Robin
  + v1.0: Add OGC API - Connected Systems - Part 2: Dynamic Data 1.0 Standard
    as ogcapi/connected-systems/part2/1.0/openapi from OGC 23-002r0

2025-07-15  Alexandre Robin
  + v1.0: Add OGC API - Connected Systems - Part 1: Feature Resources 1.0 Standard
    as ogcapi/connected-systems/part1/1.0/openapi from OGC 23-001r0

 Note: Check each OGC numbered document for detailed changes.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  https://www.ogc.org/ogc/legal/ .

OGC and OpenGIS are registered trademarks of Open Geospatial Consortium.

Copyright (c) 2025 Open Geospatial Consortium.

-----------------------------------------------------------------------

