OGC(r) OGC API - Moving Features ReadMe.txt
==================================

OGC(r) OGC API - Moving Features
-----------------------------------------------------------------------

OGC API - Moving Features

More information may be found at
 https://www.ogc.org/publications/standard/ogc-api-moving-features/

The most current schema are available at http://schemas.opengis.net/
and all OGC schemas may be downloaded in a complete bundle from
http://schemas.opengis.net/SCHEMAS_OPENGIS_NET.zip

* Latest version is: http://schemas.opengis.net/ogcapi/movingfeatures/

-----------------------------------------------------------------------

2024-10-28 Taehoon Kim, Kyoung-Sook Kim, Mahmoud SAKR, Martin Desruisseaux

  + v1.0: Added OGC API - Moving Features - Part 1: Core
    as ogcapi/movingfeatures/part1/1.0 from OGC 22-003r3

 Note: Check each OGC numbered document for detailed changes.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  https://www.ogc.org/legal/ .

OGC and OpenGIS are registered trademarks of Open Geospatial Consortium.

Copyright (c) 2024 Open Geospatial Consortium.

-----------------------------------------------------------------------

