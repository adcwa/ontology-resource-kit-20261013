OGC(r) OGC API - EDR ReadMe.txt
==================================

OGC(r) OGC API - Environmental Data Retrieval Standard
-----------------------------------------------------------------------

OGC API - Environmental Data Retrieval Standard

More information may be found at
 https://www.ogc.org/standards/ogcapi-edr

The most current schema are available at http://schemas.opengis.net/
and all OGC schemas may be downloaded in a complete bundle from
http://schemas.opengis.net/SCHEMAS_OPENGIS_NET.zip

* Latest version is: http://schemas.opengis.net/ogcapi/edr/

-----------------------------------------------------------------------

2024-09-23  Tom Kralidis, Chris Little, Mark Burgoyne, Steve Olson, Shane Mill
  + v1.0: Add OGC API - Environmental Data Retrieval - Part 2: Publish-Subscribe Workflow
    as ogcapi/edr/part2/1.0 from OGC 23-057

2023-07-25  OGC EDR API SWG
  + v1.1: Add OGC API - Environmental Data Retrieval (EDR) 1.1 Standard
    as ogcapi/edr/1.1 from OGC 19-086r6

2022-07-21  Mark Burgoyne, Chris Little, Chuck Heazel, Dave Blodgett, Tom Kralidis
  + v1.0: Update OGC API - Environmental Data Retrieval (EDR) 1.0.1 Standard
    as ogcapi/edr/1.0 from OGC 19-086r5

2021-10-05  Correction
  + v1.0: Remove 'Candidate' from OpenAPI yaml file of EDR API

2021-07-13  Mark Burgoyne, Chris Little, Chuck Heazel, Dave Blodgett, Tom Kralidis
  + v1.0: Add OGC API - Environmental Data Retrieval (EDR) 1.0 Standard
    as ogcapi/edr/1.0 from OGC 19-086r4

 Note: Check each OGC numbered document for detailed changes.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  https://www.opengeospatial.org/ogc/legal/ .

OGC and OpenGIS are registered trademarks of Open Geospatial Consortium.

Copyright (c) 2019, 2021, 2022, 2023 Open Geospatial Consortium.

-----------------------------------------------------------------------

