OGC(r) OGC API - Discrete Global Grid Systems ReadMe.txt
========================================================

OGC(r) OGC API - Discrete Global Grid Systems

-----------------------------------------------------------------------

OGC API - Discrete Global Grid Systems

More information may be found at
 https://www.ogc.org/standards/

The most current schema are available at http://schemas.opengis.net/
and all OGC schemas may be downloaded in a complete bundle from
https://schemas.opengis.net/SCHEMAS_OPENGIS_NET.zip

* Latest version is: http://schemas.opengis.net/ogcapi/dggs

-----------------------------------------------------------------------

2025-09-23 Discrete Global Grid Systems (DGGS) Standards Working Group
  + v1.0: Posted the OGC API - Discrete Global Grid Systems - Part 1: Core
    as ogcapi/dggs/1.0 from OGC 21-038r1

 Note: Check each OGC numbered document for detailed changes.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  https://www.ogc.org/legal/ .

OGC and OpenGIS are registered trademarks of Open Geospatial Consortium.

Copyright (c) 2025 Open Geospatial Consortium.

-----------------------------------------------------------------------

