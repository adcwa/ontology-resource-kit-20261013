OGC(r) OGC API - Records ReadMe.txt
==================================

OGC(r) OGC API - Records - Part 1: Core Standard
-----------------------------------------------------------------------

OGC API - Records - Part 1: Core Standard

More information may be found at
 https://www.ogc.org/standards/ogc-api-records-part-1-core

The most current schema are available at http://schemas.opengis.net/
and all OGC schemas may be downloaded in a complete bundle from
http://schemas.opengis.net/SCHEMAS_OPENGIS_NET.zip

* Latest version is: http://schemas.opengis.net/ogcapi/records

-----------------------------------------------------------------------

2025-06-09  Panagiotis (Peter) A. Vretanos, Tom Kralidis, Angelos Tzotsos
  + v1.0: Add OGC API - Records - Part 1: Core 1.0 Standard
    as ogcapi/records/part1/1.0 from OGC 20-004r1

 Note: Check each OGC numbered document for detailed changes.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  https://www.ogc.org/ogc/legal/ .

OGC and OpenGIS are registered trademarks of Open Geospatial Consortium.

Copyright (c) 2025 Open Geospatial Consortium.

-----------------------------------------------------------------------

