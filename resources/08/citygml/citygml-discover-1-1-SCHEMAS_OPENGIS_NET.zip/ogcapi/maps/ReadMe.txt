OGC(r) OGC API - Maps ReadMe.txt
=====================================

OGC(r) OGC API - Maps
-----------------------------------------------------------------------

OGC API - Maps

More information may be found at
 https://www.ogc.org/standards/ogcapi-maps

The most current schema are available at http://schemas.opengis.net/
and all OGC schemas may be downloaded in a complete bundle from
https://schemas.opengis.net/SCHEMAS_OPENGIS_NET.zip

* Latest version is: http://schemas.opengis.net/ogcapi/maps

-----------------------------------------------------------------------

2024-08-14  Joan Masó, Jérôme Jacovella-St-Louis
  + v1.0: Updated OGC API - Maps - Part 1: Core 1.0.0
    as ogcapi/maps/1.0 from OGC 20-058

2024-07-31  Joan Masó, Jérôme Jacovella-St-Louis
  + v1.0: Added OGC API - Maps - Part 1: Core 1.0.0
    as ogcapi/maps/1.0 from OGC 20-058

 Note: Check each OGC numbered document for detailed changes.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  https://www.ogc.org/ogc/legal/ .

OGC and OpenGIS are registered trademarks of Open Geospatial Consortium.

Copyright (c) 2024 Open Geospatial Consortium.

-----------------------------------------------------------------------

