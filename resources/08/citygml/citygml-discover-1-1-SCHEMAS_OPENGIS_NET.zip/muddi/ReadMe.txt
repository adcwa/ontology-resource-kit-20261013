OGC(r) OGC Model for Underground Data Definition and Integration (MUDDI) ReadMe.txt
=====================================

OGC(r) OGC Model for Underground Data Definition and Integration (MUDDI)
-----------------------------------------------------------------------

OGC Model for Underground Data Definition and Integration (MUDDI)

More information may be found at
 https://www.ogc.org/standards/muddi

The most current schema are available at http://schemas.opengis.net/
and all OGC schemas may be downloaded in a complete bundle from
https://schemas.opengis.net/SCHEMAS_OPENGIS_NET.zip

* Latest version is: http://schemas.opengis.net/muddi/

-----------------------------------------------------------------------

2024-07-31  Alan Leidner, Andrew Hughes, Carsten Roensdorf,
    Neil Brammall, Liesbeth Rombouts, Joshua Lieberman

  + v1.0: Added/Posted/Updated the OGC MUDDI 1.0.0
    as muddi/1.0 from OGC 23-024

 Note: Check each OGC numbered document for detailed changes.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  https://www.ogc.org/ogc/legal/ .

OGC and OpenGIS are registered trademarks of Open Geospatial Consortium.

Copyright (c) 2024 Open Geospatial Consortium.

-----------------------------------------------------------------------

