OGC(r) Training Data Markup Language for AI ReadMe.txt
=======================================================================

OGC(r) Training Data Markup Language for AI
-----------------------------------------------------------------------

Training Data Markup Language for AI

More information may be found at
 https://www.ogc.org/standards/trainingdml-ai/

The most current schema are available at http://schemas.opengis.net/
and all OGC schemas may be downloaded in a complete bundle from
https://schemas.opengis.net/SCHEMAS_OPENGIS_NET.zip

* Latest version is: http://schemas.opengis.net/trainingdml-ai/

-----------------------------------------------------------------------

2025-09-17 TrainingDML-AI Standards Working Group
  + v1.0: Added OGC Training Data Markup Language for Artificial Intelligence
    (TrainingDML-AI) Part 2: JSON 1.0.0 Encoding Standard
    as trainingdml-ai/part2/1.0 from OGC 24-006r1

2025-09-17 TrainingDML-AI Standards Working Group
  + v1.0: Added OGC Training Data Markup Language for Artificial Intelligence
    (TrainingDML-AI) Part 3: XML 1.0.0 Encoding Standard
    as trainingdml-ai/part3/1.0 from OGC 24-007r1

 Note: Check each OGC numbered document for detailed changes.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  https://www.ogc.org/legal/ .

OGC and OpenGIS are registered trademarks of Open Geospatial Consortium.

Copyright (c) 2025 Open Geospatial Consortium.

-----------------------------------------------------------------------

