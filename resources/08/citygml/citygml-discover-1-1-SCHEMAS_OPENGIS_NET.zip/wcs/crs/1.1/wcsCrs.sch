<?xml version="1.0" encoding="UTF-8"?>
<!-- 
    This Schematron Document is part of the WCS CRS Extension [OGC 11-053]
    which enables expressing Coordinate Reference Sytems (CRSs) in WCS client/server communication.
    Last updated: 2019-jun-06
    Copyright (c) 2019 Open Geospatial Consortium, Inc. All Rights Reserved.
    To obtain additional rights of use, visit http://www.opengeospatial.org/legal/.
-->
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
    <sch:title>WCS CRS Extension Schematron Rules</sch:title>
    <sch:ns uri="http://www.opengis.net/wcs/2.1/gml" prefix="wcs"/>
    <sch:ns uri="http://www.w3.org/1999/xlink" prefix="xlink"/>
    <sch:pattern>
        <sch:title>Requirement 1: /req/crs/extension-identifier</sch:title>
        <sch:rule context="//wcs:Capabilities">
            <sch:let name="profiles" value="string-join(//*[local-name()='ServiceIdentification']/*[local-name()='Profile'],' ')"/>
            <sch:assert test="contains($profiles,'http://www.opengis.net/spec/WCS_service-extension_crs/1.1/conf/crs')">
                To indicate that the WCS CRS extension is implemented by this server, there shall be a profile element containing the WCS CRS Extension identifier.
            </sch:assert>
        </sch:rule>
    </sch:pattern>
    <sch:pattern>
        <sch:title>Requirement 3: /req/crs/wcsServiceMetadata-crs</sch:title>
        <sch:rule context="//wcs:Capabilities">
            <sch:assert test="count(//*[local-name()='CrsMetadata'])=1">
                The Capabilities document shall contain one CrsMetadata element.
            </sch:assert>
        </sch:rule>
    </sch:pattern>
    <sch:pattern>
        <sch:title>Requirement 6: /req/crs/getCoverage-crs</sch:title>
        <sch:rule context="//wcs:GetCoverage">
            <sch:assert test="count(//*[local-name()='Crs'])=1">
                There shall be exactly one Crs element.
            </sch:assert>
        </sch:rule>
    </sch:pattern>
</sch:schema>
